<?php
/**
 * Plugin Name: NOCODYA · Vídeo demo
 * Description: Página del vídeo de la campaña «Tu web demo gratis» en /v/<empresa>/. La primera vez que una empresa le da al play, avisa por email a nocodya@gmail.com. La lista de quién lo ha visto está en Herramientas → Vídeo demo.
 * Version: 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const NCV_VER      = '1.0.0';
const NCV_AVISO    = 'nocodya@gmail.com';   // a dónde llegan los avisos
const NCV_WHATSAPP = '34624931947';
const NCV_TZ       = 'Europe/Madrid';

// Empresas de la campaña: slug => [empresa, email, movil, cuenta]. Se guardan desde Herramientas → Vídeo demo.
function ncv_empresas() {
	$e = get_option( 'ncv_empresas', array() );
	return is_array( $e ) ? $e : array();
}

// Lo que ha pasado con cada enlace: slug => [abierto, abierto_n, play, play_n, pct, ultimo, avisado] (horas en unix).
function ncv_vistas() {
	$v = get_option( 'ncv_vistas', array() );
	return is_array( $v ) ? $v : array();
}

function ncv_rewrite() {
	add_rewrite_rule( '^v/([a-z0-9-]{1,80})/?$', 'index.php?ncv_slug=$matches[1]', 'top' );
}
add_action( 'init', 'ncv_rewrite' );

add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'ncv_slug';
	return $vars;
} );

register_activation_hook( __FILE__, function () {
	ncv_rewrite();
	flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

// La regla /v/ se registra también al actualizar el plugin sin reactivarlo.
add_action( 'init', function () {
	if ( get_option( 'ncv_rewrite_ver' ) !== NCV_VER ) {
		flush_rewrite_rules();
		update_option( 'ncv_rewrite_ver', NCV_VER );
	}
}, 99 );

function ncv_fecha( $ts ) {
	return $ts ? wp_date( 'D j M, H:i', (int) $ts, new DateTimeZone( NCV_TZ ) ) : '—';
}

// ─── La página del vídeo ────────────────────────────────────────────────────────────────────────────────

add_action( 'template_redirect', function () {
	$slug = get_query_var( 'ncv_slug' );
	if ( ! $slug ) {
		return;
	}
	$slug = sanitize_title( $slug );
	$emps = ncv_empresas();
	$emp  = isset( $emps[ $slug ] ) ? $emps[ $slug ] : null;

	// Cada visita tiene que llegar a WordPress: sin caché de LiteSpeed ni de la CDN, y fuera de Google.
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'nocodya-video' );
	nocache_headers();
	header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private' );
	header( 'X-Robots-Tag: noindex, nofollow' );

	$a       = plugins_url( 'assets/', __FILE__ );
	$nombre  = $emp ? $emp['empresa'] : '';
	$cuenta  = ( $emp && ! empty( $emp['cuenta'] ) ) ? $emp['cuenta'] : NCV_AVISO;
	$titulo  = $nombre ? $nombre . ', mira cómo quedaría tu negocio con web' : 'Mira cómo quedaría tu negocio con web';
	$mailto  = 'mailto:' . $cuenta . '?subject=' . rawurlencode( 'Quiero mi demo gratis' . ( $nombre ? ' · ' . $nombre : '' ) )
		. '&body=' . rawurlencode( 'SÍ, quiero mi demo gratis.' );
	$wa      = 'https://wa.me/' . NCV_WHATSAPP . '?text=' . rawurlencode( 'Hola Silvestre, ' . ( $nombre ? 'soy de ' . $nombre . '. ' : '' ) . 'Quiero mi demo gratis.' );
	$api     = rest_url( 'ncv/v1/evento' );
	$check   = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M4 10.5l4 4 8-9" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>';

	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?php echo esc_html( $titulo ); ?> · NOCODYA</title>
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="Te preparamos gratis una demo de tu web con tu logo, tus fotos y tus obras.">
<meta name="theme-color" content="#120302">
<link rel="icon" href="<?php echo esc_url( $a . 'favicon.svg' ); ?>" type="image/svg+xml">
<link rel="preload" href="<?php echo esc_url( $a . 'spacegrotesk.woff2' ); ?>" as="font" type="font/woff2" crossorigin>
<style>
@font-face { font-family: 'Space Grotesk'; src: url(<?php echo esc_url( $a . 'spacegrotesk.woff2' ); ?>) format('woff2'); font-weight: 300 700; font-display: swap; }
@font-face { font-family: 'Space Mono'; src: url(<?php echo esc_url( $a . 'spacemono.woff2' ); ?>) format('woff2'); font-weight: 400; font-display: swap; }
:root { --crema: #FBEBD6; --tinta: #2B0C05; --sol: #FFB01F; --fondo: #120302; --linea: rgba(251, 235, 214, .14); --suave: rgba(251, 235, 214, .66);
  --disp: 'Space Grotesk', system-ui, sans-serif; --mono: 'Space Mono', ui-monospace, monospace; --pad: clamp(16px, 4vw, 48px); }
*, *::before, *::after { box-sizing: border-box; }
html { -webkit-text-size-adjust: 100%; }
body { margin: 0; min-height: 100vh; background: radial-gradient(120% 80% at 70% 0%, #3a1206 0%, var(--fondo) 62%) fixed, var(--fondo);
  color: var(--crema); font-family: var(--disp); -webkit-font-smoothing: antialiased; }
a { color: inherit; }
.marca { display: flex; align-items: center; gap: 10px; padding: 18px var(--pad); font-family: var(--mono); font-size: 13px; letter-spacing: .14em; text-decoration: none; }
.marca img { width: 30px; height: 30px; }
main { display: grid; gap: clamp(24px, 4vw, 64px); align-items: center; max-width: 1080px; margin: 0 auto; padding: 8px var(--pad) 48px;
  grid-template-columns: minmax(0, 1fr); }
.texto { display: grid; gap: 20px; }
.etiqueta { font-family: var(--mono); font-size: 12px; letter-spacing: .16em; text-transform: uppercase; color: var(--sol); margin: 0; }
h1 { font-weight: 600; font-size: clamp(30px, 6.4vw, 52px); line-height: 1.04; letter-spacing: -.02em; margin: 0; text-wrap: balance; }
.lead { font-size: clamp(16px, 2.2vw, 19px); line-height: 1.5; color: var(--suave); margin: 0; max-width: 34em; }
.video { position: relative; width: min(100%, 380px); margin: 0 auto; aspect-ratio: 9 / 16; border-radius: 22px; overflow: hidden;
  background: #000; box-shadow: 0 30px 80px -30px rgba(255, 120, 40, .35), 0 0 0 1px var(--linea); }
.video video { display: block; width: 100%; height: 100%; object-fit: cover; }
.play { position: absolute; inset: 0; display: grid; place-items: end center; border: 0; padding: 0 0 64px; background: linear-gradient(180deg, rgba(18,3,2,0) 40%, rgba(18,3,2,.55));
  cursor: pointer; color: var(--tinta); font: inherit; }
.play span { display: grid; place-items: center; width: 84px; height: 84px; border-radius: 50%; background: var(--sol);
  box-shadow: 0 0 0 10px rgba(255, 176, 31, .22); transition: transform .3s cubic-bezier(.22, 1, .36, 1); }
.play:hover span, .play:focus-visible span { transform: scale(1.06); }
.play svg { width: 30px; height: 30px; margin-left: 5px; }
.play em { position: absolute; bottom: 22px; left: 0; right: 0; text-align: center; font-style: normal; font-family: var(--mono); font-size: 12px;
  letter-spacing: .14em; text-transform: uppercase; color: var(--crema); }
.play[hidden] { display: none; }
ul { list-style: none; margin: 0; padding: 0; display: grid; gap: 12px; }
li { display: flex; gap: 12px; align-items: flex-start; font-size: 17px; line-height: 1.4; }
li svg { flex: none; width: 22px; height: 22px; padding: 3px; border-radius: 50%; color: var(--tinta); background: var(--sol); margin-top: 1px; }
.botones { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 4px; }
.btn { display: inline-flex; align-items: center; justify-content: center; gap: 10px; min-height: 52px; padding: 0 24px; border-radius: 999px;
  font-weight: 600; font-size: 16px; text-decoration: none; transition: transform .25s cubic-bezier(.22, 1, .36, 1), background .25s; }
.btn:hover { transform: translateY(-2px); }
.btn-sol { background: var(--sol); color: var(--tinta); }
.btn-linea { border: 1px solid rgba(251, 235, 214, .4); color: var(--crema); }
.btn-linea:hover { background: rgba(251, 235, 214, .08); }
.btn svg { width: 20px; height: 20px; }
.firma { font-size: 14px; color: var(--suave); margin: 4px 0 0; }
footer { max-width: 1080px; margin: 0 auto; padding: 20px var(--pad) 32px; border-top: 1px solid var(--linea); font-size: 12px; line-height: 1.5; color: rgba(251, 235, 214, .5); }
@media (min-width: 860px) {
  main { grid-template-columns: 380px minmax(0, 1fr); grid-template-areas: "video t1" "video t2"; align-items: end; row-gap: 32px; padding-top: 32px; }
  .t1 { grid-area: t1; } .t2 { grid-area: t2; align-self: start; } .video { grid-area: video; margin: 0; align-self: center; }
}
@media (max-width: 859px) {
  .botones .btn { flex: 1 1 100%; }
}
@media (prefers-reduced-motion: reduce) { * { transition: none !important; } }
</style>
</head>
<body data-s="<?php echo esc_attr( $slug ); ?>" data-api="<?php echo esc_url( $api ); ?>">
<a class="marca" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( $a . 'favicon.svg' ); ?>" alt="" width="30" height="30">NOCODYA</a>
<main>
  <div class="texto t1">
    <p class="etiqueta">Demo gratis · 30 segundos</p>
    <h1><?php echo esc_html( $titulo ); ?></h1>
    <p class="lead">Te preparamos una demo gratis con tu logo, tus fotos y tus obras. La ves en tu móvil antes de decidir nada.</p>
  </div>
  <div class="video">
    <video id="v" src="<?php echo esc_url( $a . 'demo.mp4' ); ?>" poster="<?php echo esc_url( $a . 'portada.webp' ); ?>" width="720" height="1280" playsinline preload="metadata"></video>
    <button class="play" id="play" type="button" aria-label="Ver el vídeo">
      <span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4.5v15l13-7.5z" fill="currentColor"/></svg></span>
      <em>Ver el vídeo · 34 s</em>
    </button>
  </div>
  <div class="texto t2">
    <ul>
      <li><?php echo $check; // phpcs:ignore ?>Demo gratis en menos de 48 h</li>
      <li><?php echo $check; // phpcs:ignore ?>Si te gusta, la terminamos juntos</li>
      <li><?php echo $check; // phpcs:ignore ?>Si no, te la quedas y no te comprometes a nada</li>
    </ul>
    <div class="botones">
      <a class="btn btn-sol" id="b-mail" href="<?php echo esc_url( $mailto, array( 'mailto' ) ); ?>">Quiero mi demo gratis</a>
      <a class="btn btn-linea" id="b-wa" href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.6.1-.7.8-.8 1-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.7 11.8 11.8 0 0 0 4.5 4c1.7.7 2.3.8 3.2.6a2.7 2.7 0 0 0 1.8-1.2 2.2 2.2 0 0 0 .2-1.2c-.1-.1-.3-.2-.5-.3z"/></svg>Escríbeme por WhatsApp</a>
    </div>
    <p class="firma">Silvestre · CEO de NOCODYA · nocodya.es · <span style="white-space:nowrap">624 931 947</span></p>
  </div>
</main>
<footer>NOCODYA · Silvestre Juan Mbantutumo Obama. Esta página no usa cookies: solo anota si se reproduce el vídeo, para saber si te ha llegado. <a href="<?php echo esc_url( home_url( '/privacidad/' ) ); ?>">Privacidad</a></footer>
<script>
(function () {
  var s = document.body.dataset.s, api = document.body.dataset.api;
  function ev(e, p) {
    if (navigator.webdriver) return;
    var f = new FormData(); f.append('s', s); f.append('e', e); if (p != null) f.append('p', p);
    try { if (navigator.sendBeacon && navigator.sendBeacon(api, f)) return; } catch (x) {}
    fetch(api, { method: 'POST', body: f, keepalive: true }).catch(function () {});
  }
  // «abierto»: la página ha estado a la vista 2 s en un navegador de verdad (no cuenta como aviso, solo se anota)
  var abierto = false, t = null;
  function mirar() {
    clearTimeout(t);
    if (!abierto && document.visibilityState === 'visible') t = setTimeout(function () { abierto = true; ev('abierto'); }, 2000);
  }
  document.addEventListener('visibilitychange', mirar); mirar();

  var v = document.getElementById('v'), b = document.getElementById('play'), jugado = false, hitos = [25, 50, 75, 100];
  b.addEventListener('click', function () { b.hidden = true; v.controls = true; var p = v.play(); if (p && p.catch) p.catch(function () {}); });
  v.addEventListener('play', function () { b.hidden = true; v.controls = true; if (!jugado) { jugado = true; ev('play'); } });
  v.addEventListener('timeupdate', function () {
    if (!v.duration) return;
    var pct = v.currentTime / v.duration * 100;
    while (hitos.length && pct >= hitos[0] - 1) ev('pct', hitos.shift());
  });
  v.addEventListener('ended', function () { if (hitos.length) { hitos = []; ev('pct', 100); } });
  document.getElementById('b-mail').addEventListener('click', function () { ev('boton', 'email'); });
  document.getElementById('b-wa').addEventListener('click', function () { ev('boton', 'whatsapp'); });
})();
</script>
</body>
</html>
	<?php
	exit;
} );

// ─── Registro de lo que pasa en la página y aviso por email ─────────────────────────────────────────────

add_action( 'rest_api_init', function () {
	register_rest_route( 'ncv/v1', '/evento', array(
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => 'ncv_evento',
	) );
} );

function ncv_evento( WP_REST_Request $r ) {
	$slug = sanitize_title( (string) $r->get_param( 's' ) );
	$e    = (string) $r->get_param( 'e' );
	$ua   = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
	if ( ! $slug || strlen( $slug ) > 80 || ! in_array( $e, array( 'abierto', 'play', 'pct', 'boton' ), true )
		|| '' === $ua || preg_match( '/bot|crawl|spider|slurp|preview|headless|scan|python|curl|wget|java\/|go-http/i', $ua ) ) {
		return new WP_REST_Response( null, 204 );
	}

	$vistas = ncv_vistas();
	$x      = isset( $vistas[ $slug ] ) ? $vistas[ $slug ] : array( 'abierto' => 0, 'abierto_n' => 0, 'play' => 0, 'play_n' => 0, 'pct' => 0, 'boton' => '', 'ultimo' => 0, 'avisado' => 0 );
	$ahora  = time();

	if ( 'abierto' === $e ) {
		$x['abierto'] = $x['abierto'] ? $x['abierto'] : $ahora;
		$x['abierto_n']++;
	} elseif ( 'play' === $e ) {
		$x['play'] = $x['play'] ? $x['play'] : $ahora;
		$x['play_n']++;
	} elseif ( 'pct' === $e ) {
		$x['pct'] = max( (int) $x['pct'], min( 100, absint( $r->get_param( 'p' ) ) ) );
	} else {
		$btn        = 'whatsapp' === $r->get_param( 'p' ) ? 'WhatsApp' : 'Email';
		$x['boton'] = false === strpos( (string) $x['boton'], $btn ) ? trim( $x['boton'] . ' ' . $btn ) : $x['boton'];
	}
	$x['ultimo'] = $ahora;

	// El aviso sale una sola vez por empresa, la primera vez que le dan al play (los antivirus de correo abren enlaces, pero no reproducen).
	$emps = ncv_empresas();
	$avisar = 'play' === $e && ! $x['avisado'] && isset( $emps[ $slug ] );
	if ( $avisar ) {
		$x['avisado'] = $ahora;
	}
	$vistas[ $slug ] = $x;
	update_option( 'ncv_vistas', $vistas, false );

	if ( $avisar ) {
		ncv_avisar( $slug, $emps[ $slug ], $ahora );
	}
	return new WP_REST_Response( null, 204 );
}

function ncv_avisar( $slug, $emp, $cuando ) {
	$movil  = isset( $emp['movil'] ) ? preg_replace( '/\D/', '', $emp['movil'] ) : '';
	$asunto = '👀 ' . $emp['empresa'] . ' ha visto tu vídeo';
	$lineas = array(
		$emp['empresa'] . ' le ha dado al play al vídeo de la demo gratis.',
		'',
		'Cuándo: ' . ncv_fecha( $cuando ),
		'Correo: ' . $emp['email'] . ( ! empty( $emp['cuenta'] ) ? ' (se le escribió desde ' . $emp['cuenta'] . ')' : '' ),
	);
	if ( $movil ) {
		$lineas[] = 'Teléfono: ' . $emp['movil'];
		$lineas[] = 'WhatsApp: https://wa.me/34' . substr( $movil, -9 );
	}
	$lineas[] = '';
	$lineas[] = 'Su página: ' . home_url( '/v/' . $slug . '/' );
	$lineas[] = 'Lista completa: ' . admin_url( 'tools.php?page=nocodya-video' );
	wp_mail( NCV_AVISO, $asunto, implode( "\n", $lineas ), array( 'Content-Type: text/plain; charset=UTF-8', 'From: NOCODYA avisos <wordpress@nocodya.es>' ) );
}

// ─── Herramientas → Vídeo demo ──────────────────────────────────────────────────────────────────────────

add_action( 'admin_menu', function () {
	add_management_page( 'Vídeo demo: quién lo ha visto', 'Vídeo demo', 'manage_options', 'nocodya-video', 'ncv_pantalla' );
} );

add_action( 'admin_post_ncv_empresas', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Sin permiso' );
	}
	check_admin_referer( 'ncv_empresas' );
	$json  = json_decode( wp_unslash( isset( $_POST['ncv_json'] ) ? $_POST['ncv_json'] : '' ), true ); // phpcs:ignore
	$ok    = is_array( $json );
	if ( $ok ) {
		$limpio = array();
		foreach ( $json as $slug => $d ) {
			$slug = sanitize_title( $slug );
			if ( $slug && is_array( $d ) && ! empty( $d['empresa'] ) ) {
				$limpio[ $slug ] = array(
					'empresa' => sanitize_text_field( $d['empresa'] ),
					'email'   => sanitize_email( isset( $d['email'] ) ? $d['email'] : '' ),
					'movil'   => sanitize_text_field( isset( $d['movil'] ) ? $d['movil'] : '' ),
					'cuenta'  => sanitize_email( isset( $d['cuenta'] ) ? $d['cuenta'] : '' ),
				);
			}
		}
		update_option( 'ncv_empresas', $limpio, false );
		// lo anotado de enlaces que ya no están en la lista (por ejemplo, el de prueba) se quita
		update_option( 'ncv_vistas', array_intersect_key( ncv_vistas(), $limpio ), false );
	}
	wp_safe_redirect( admin_url( 'tools.php?page=nocodya-video&guardado=' . ( $ok ? count( $limpio ) : 'error' ) ) );
	exit;
} );

function ncv_pantalla() {
	$emps   = ncv_empresas();
	$vistas = ncv_vistas();
	uasort( $vistas, function ( $a, $b ) {
		return $b['ultimo'] - $a['ultimo'];
	} );
	$vistos = count( array_filter( $vistas, function ( $x ) {
		return $x['play'];
	} ) );
	?>
	<div class="wrap">
		<h1>Vídeo demo: quién lo ha visto</h1>
		<?php if ( isset( $_GET['guardado'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-<?php echo 'error' === $_GET['guardado'] ? 'error' : 'success'; // phpcs:ignore ?> is-dismissible"><p><?php echo 'error' === $_GET['guardado'] ? 'El texto no es un JSON válido.' : 'Empresas guardadas: ' . (int) $_GET['guardado']; // phpcs:ignore ?></p></div>
		<?php endif; ?>
		<p><?php echo (int) count( $emps ); ?> enlaces de empresas · <strong><?php echo (int) $vistos; ?></strong> le han dado al play. El aviso a <?php echo esc_html( NCV_AVISO ); ?> sale la primera vez que una empresa reproduce el vídeo.</p>
		<table class="widefat striped">
			<thead><tr><th>Empresa</th><th>Abrió la página</th><th>Le dio al play</th><th>Hasta</th><th>Botón</th><th>Última vez</th></tr></thead>
			<tbody>
			<?php if ( ! $vistas ) : ?>
				<tr><td colspan="6">Todavía nadie ha abierto ningún enlace.</td></tr>
			<?php endif; ?>
			<?php foreach ( $vistas as $slug => $x ) : $emp = isset( $emps[ $slug ] ) ? $emps[ $slug ] : null; ?>
				<tr>
					<td><strong><?php echo esc_html( $emp ? $emp['empresa'] : $slug . ' (sin empresa)' ); ?></strong><?php if ( $emp ) : ?><br><small><?php echo esc_html( $emp['email'] . ( $emp['movil'] ? ' · ' . $emp['movil'] : '' ) ); ?></small><?php endif; ?></td>
					<td><?php echo esc_html( $x['abierto'] ? ncv_fecha( $x['abierto'] ) . ( $x['abierto_n'] > 1 ? ' (' . $x['abierto_n'] . ' veces)' : '' ) : '—' ); ?></td>
					<td><?php echo esc_html( $x['play'] ? ncv_fecha( $x['play'] ) . ( $x['play_n'] > 1 ? ' (' . $x['play_n'] . ' veces)' : '' ) : '—' ); ?></td>
					<td><?php echo $x['pct'] ? (int) $x['pct'] . ' %' : '—'; ?></td>
					<td><?php echo esc_html( $x['boton'] ? $x['boton'] : '—' ); ?></td>
					<td><?php echo esc_html( ncv_fecha( $x['ultimo'] ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<h2 style="margin-top:32px">Empresas de la campaña</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="ncv_empresas">
			<?php wp_nonce_field( 'ncv_empresas' ); ?>
			<p>JSON con <code>{"slug": {"empresa", "email", "movil", "cuenta"}}</code>. El enlace de cada una es nocodya.es/v/<em>slug</em>/.</p>
			<textarea name="ncv_json" rows="10" class="large-text code"><?php echo esc_textarea( wp_json_encode( $emps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?></textarea>
			<?php submit_button( 'Guardar empresas', 'secondary' ); ?>
		</form>
	</div>
	<?php
}
