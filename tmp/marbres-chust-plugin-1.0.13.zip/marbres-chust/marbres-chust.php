<?php
/**
 * Plugin Name: Marbres Chust · Web
 * Description: Sirve la web de Marbres Chust (portada, 6 servicios, trabajos, contacto y 404). Las fotos y vídeos se guardan en wp-content/uploads/marbres-chust/ con «Herramientas → Marbres Chust: fotos y vídeos». Desactivar el plugin devuelve WordPress tal cual.
 * Version:     1.0.13
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const MC_VER    = '1.0.13';
const MC_ORIGEN = 'https://nocodya-hue.github.io/marbres-chust/media/';   // copia pública de las fotos y vídeos

function mc_paginas() {
	return array( 'encimeras-de-cocina', 'banos', 'piscinas-y-exterior', 'escaleras', 'mesas-de-piedra', 'revestimientos-y-a-medida', 'trabajos', 'contacto' );
}

function mc_subidas() {
	$u = wp_upload_dir( null, false );
	return array( 'dir' => $u['basedir'] . '/marbres-chust/', 'url' => set_url_scheme( $u['baseurl'] . '/marbres-chust/' ) );
}

function mc_reglas() {
	foreach ( mc_paginas() as $slug ) {
		add_rewrite_rule( '^' . $slug . '/?$', 'index.php?mc_pagina=' . $slug, 'top' );
	}
	add_rewrite_rule( '^sitemap\.xml$', 'index.php?mc_pagina=sitemap', 'top' );
}
add_action( 'init', 'mc_reglas' );
add_filter( 'query_vars', function ( $v ) {
	$v[] = 'mc_pagina';
	return $v;
} );
add_filter( 'wp_sitemaps_enabled', '__return_false' );   // el sitemap propio ya lleva páginas, fotos y vídeos
add_filter( 'robots_txt', function ( $txt ) {
	return $txt . "\nSitemap: " . home_url( '/sitemap.xml' ) . "\n";
} );

// Rutas del HTML compilado → archivos del plugin (assets) y de uploads (media y media.json)
function mc_reescribe( $html ) {
	$plg  = plugins_url( 'site/', __FILE__ );
	$upl  = mc_subidas()['url'];
	$casa = untrailingslashit( 'https://marbreschust.es' );
	$html = str_replace( array( $casa . '/media/', $casa . '/assets/' ), array( $upl . 'media/', $plg . 'assets/' ), $html );
	$html = preg_replace( '#data-base="(?:\.\./)*/?"#', 'data-base="' . $upl . '"', $html );
	$html = preg_replace( '#(?<=["\'\s,(])(?:\.\./)*/?media/#', $upl . 'media/', $html );
	$html = preg_replace( '#(?<=["\'\s,(])(?:\.\./)*/?assets/#', $plg . 'assets/', $html );
	if ( home_url() !== $casa ) {   // por si algún día cambia el dominio
		$html = str_replace( $casa, untrailingslashit( home_url() ), $html );
	}
	return $html;
}

function mc_sirve( $archivo, $estado = 200, $tipo = 'text/html; charset=utf-8' ) {
	$ruta = __DIR__ . '/site/' . $archivo;
	if ( ! is_readable( $ruta ) ) {
		return;
	}
	$html = mc_reescribe( file_get_contents( $ruta ) );
	$g    = get_option( 'mc_google_verif' );
	if ( $g && 0 === strpos( $tipo, 'text/html' ) ) {   // verificación de Search Console
		$html = preg_replace( '#</head>#', '<meta name="google-site-verification" content="' . esc_attr( $g ) . '">' . "\n</head>", $html, 1 );
	}
	status_header( $estado );
	header( 'Content-Type: ' . $tipo );
	echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	exit;
}

// www.marbreschust.es → marbreschust.es (301): una sola dirección para Google y para las visitas, y así las fuentes
// del plugin (que se piden a la dirección sin www) no llegan desde otro dominio y el navegador no las bloquea (CORS).
// Va antes de servir las páginas (prioridad 0) y solo en la parte pública: el panel, AJAX y la API no pasan por aquí.
add_action( 'template_redirect', function () {
	$casa = wp_parse_url( home_url(), PHP_URL_HOST );
	$pide = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) ) : '';
	if ( $casa && 'www.' . $casa === $pide ) {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
		wp_safe_redirect( 'https://' . $casa . $uri, 301 );
		exit;
	}
}, 0 );

add_action( 'template_redirect', function () {
	$pag = get_query_var( 'mc_pagina' );
	if ( 'sitemap' === $pag ) {
		mc_sirve( 'sitemap.xml', 200, 'application/xml; charset=utf-8' );
	}
	if ( $pag && in_array( $pag, mc_paginas(), true ) ) {
		mc_sirve( $pag . '/index.html' );
	}
	if ( ( is_front_page() || is_home() ) && ! is_feed() && ! is_search() && ! is_paged() ) {
		mc_sirve( 'index.html' );
	}
	if ( is_404() ) {
		// direcciones antiguas /media/… (sitemap de imágenes) → donde están ahora
		$ruta = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' );
		if ( 0 === strpos( $ruta, 'media/' ) ) {
			wp_safe_redirect( mc_subidas()['url'] . $ruta, 301 );
			exit;
		}
		mc_sirve( '404.html', 404 );
	}
}, 1 );

// ---------- fotos y vídeos: copia servidor a servidor desde la copia pública ----------
function mc_manifiesto() {
	static $m = null;
	if ( null === $m ) {
		$m = json_decode( file_get_contents( __DIR__ . '/manifiesto.json' ), true );
	}
	return $m;
}

function mc_estado() {
	$dir = mc_subidas()['dir'] . 'media/';
	$hay = 0;
	$mb  = 0;
	foreach ( mc_manifiesto() as $f ) {
		if ( is_file( $dir . $f[0] ) && filesize( $dir . $f[0] ) === (int) $f[1] ) {
			$hay++;
			$mb += $f[1];
		}
	}
	return array( 'hay' => $hay, 'total' => count( mc_manifiesto() ), 'mb' => round( $mb / 1048576 ) );
}

function mc_copia_json() {
	$s = mc_subidas();
	wp_mkdir_p( $s['dir'] );
	copy( __DIR__ . '/site/media.json', $s['dir'] . 'media.json' );
}

add_action( 'admin_menu', function () {
	add_management_page( 'Marbres Chust: fotos y vídeos', 'Marbres Chust: fotos y vídeos', 'manage_options', 'marbres-chust', 'mc_pantalla' );
} );

function mc_pantalla() {
	$e = mc_estado();
	?>
	<div class="wrap">
		<h1>Marbres Chust: fotos y vídeos</h1>
		<p>La web necesita sus <?php echo (int) $e['total']; ?> archivos de fotos y vídeos (unos 473 MB). Este botón los copia directamente al servidor desde la copia pública de la web; se puede parar y seguir cuando quieras, los que ya están no se vuelven a copiar.</p>
		<p><strong id="mc-estado"><?php echo (int) $e['hay']; ?> de <?php echo (int) $e['total']; ?> archivos (<?php echo (int) $e['mb']; ?> MB)</strong></p>
		<div style="max-width:560px;height:10px;background:#e5e5e5;border-radius:6px;overflow:hidden;margin:8px 0 16px"><div id="mc-barra" style="height:100%;width:<?php echo esc_attr( round( 100 * $e['hay'] / max( 1, $e['total'] ) ) ); ?>%;background:#2271b1"></div></div>
		<p><button class="button button-primary" id="mc-copiar">Copiar fotos y vídeos</button> <span id="mc-msg"></span></p>
		<h2 style="margin-top:32px">Google Search Console</h2>
		<p>Pega aquí la etiqueta HTML que da Search Console para verificar la propiedad (la etiqueta entera o solo el código).</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="mc_google">
			<?php wp_nonce_field( 'mc_google' ); ?>
			<input type="text" name="mc_google" id="mc-google" class="regular-text code" value="<?php echo esc_attr( get_option( 'mc_google_verif', '' ) ); ?>" placeholder="&lt;meta name=&quot;google-site-verification&quot; content=&quot;…&quot;&gt;">
			<?php submit_button( 'Guardar', 'secondary', 'submit', false ); ?>
		</form>
	</div>
	<script>
	(function () {
		const b = document.getElementById('mc-copiar'), est = document.getElementById('mc-estado'), barra = document.getElementById('mc-barra'), msg = document.getElementById('mc-msg');
		let desde = 0, errores = 0;
		async function tanda() {
			const fd = new FormData();
			fd.append('action', 'mc_importar'); fd.append('desde', desde); fd.append('_wpnonce', '<?php echo esc_js( wp_create_nonce( 'mc_importar' ) ); ?>');
			const r = await fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' }).then((x) => x.json()).catch(() => null);
			if (!r || !r.success) { msg.textContent = 'Fallo de conexión, reintentando…'; setTimeout(tanda, 3000); return; }
			const d = r.data; desde = d.siguiente; errores += d.errores;
			est.textContent = d.hay + ' de ' + d.total + ' archivos (' + d.mb + ' MB)';
			barra.style.width = Math.round(100 * d.hay / d.total) + '%';
			if (desde < d.total) { msg.textContent = 'Copiando…'; tanda(); }
			else { msg.textContent = errores ? ('Terminado con ' + errores + ' fallos: vuelve a pulsar para reintentarlos.') : 'Terminado.'; b.disabled = false; }
		}
		b.addEventListener('click', () => { b.disabled = true; desde = 0; errores = 0; msg.textContent = 'Copiando…'; tanda(); });
	})();
	</script>
	<?php
}

add_action( 'admin_post_mc_google', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'sin permiso' );
	}
	check_admin_referer( 'mc_google' );
	$v = trim( wp_unslash( $_POST['mc_google'] ?? '' ) );
	if ( preg_match( '#content=["\']([^"\']+)["\']#', $v, $m ) ) {   // se acepta la etiqueta entera
		$v = $m[1];
	}
	update_option( 'mc_google_verif', sanitize_text_field( $v ) );
	do_action( 'litespeed_purge_all' );
	wp_safe_redirect( admin_url( 'tools.php?page=marbres-chust&guardado=1' ) );
	exit;
} );

add_action( 'wp_ajax_mc_importar', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mc_importar', '_wpnonce', false ) ) {
		wp_send_json_error( 'sin permiso', 403 );
	}
	@set_time_limit( 120 ); // phpcs:ignore
	$m     = mc_manifiesto();
	$dir   = mc_subidas()['dir'] . 'media/';
	$i     = max( 0, (int) ( $_POST['desde'] ?? 0 ) );
	$fin   = microtime( true ) + 20;
	$err   = 0;
	for ( ; $i < count( $m ) && microtime( true ) < $fin; $i++ ) {
		list( $rel, $tam ) = $m[ $i ];
		if ( ! preg_match( '#^[a-z0-9/_.-]+$#i', $rel ) || false !== strpos( $rel, '..' ) ) {
			$err++;
			continue;
		}
		$dest = $dir . $rel;
		if ( is_file( $dest ) && filesize( $dest ) === (int) $tam ) {
			continue;
		}
		wp_mkdir_p( dirname( $dest ) );
		$tmp = $dest . '.parte';
		$r   = wp_remote_get( MC_ORIGEN . $rel, array( 'timeout' => 60, 'stream' => true, 'filename' => $tmp ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) || ! is_file( $tmp ) || filesize( $tmp ) !== (int) $tam ) {
			@unlink( $tmp ); // phpcs:ignore
			$err++;
			continue;
		}
		rename( $tmp, $dest );
	}
	mc_copia_json();
	$e = mc_estado();
	wp_send_json_success( array( 'siguiente' => $i, 'errores' => $err, 'hay' => $e['hay'], 'total' => $e['total'], 'mb' => $e['mb'] ) );
} );

register_activation_hook( __FILE__, function () {
	mc_reglas();
	flush_rewrite_rules();
	mc_copia_json();
	do_action( 'litespeed_purge_all' );
} );
register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
	do_action( 'litespeed_purge_all' );
} );

// reglas nuevas al actualizar el plugin sin reactivarlo
add_action( 'init', function () {
	if ( get_option( 'mc_ver' ) !== MC_VER ) {
		flush_rewrite_rules();
		mc_copia_json();
		update_option( 'mc_ver', MC_VER );
	}
}, 99 );
